export interface Product {
    pID: string;
    pDesc: string;
    pqty: number;
    priceperunit : number
    rqty:number;
}